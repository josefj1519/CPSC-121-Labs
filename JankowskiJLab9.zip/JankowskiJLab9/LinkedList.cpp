
#include "LinkedList.h"
/*
CPSC 121 Lab 9
by Josef Jankowski
Dec 18 2018
*/

//needed Classname<T>::Classname(){} for it to compitle
template <class T>
LinkedList<T>::~LinkedList(){

  //traverses throug linked lists, unlinks them and deletes
  Node<T> *curnode;
  Node<T> *nextnode;
  curnode = head;

  while(curnode!=NULL){
    //set nextnode to the one after we are goin to delete
    nextnode = curnode->next;
    //delete current node that we are on
     delete curnode;
     //set the nodes equal to each other
     curnode = nextnode;
  }



}

template <class T>
int LinkedList<T>::size(){

  Node<T> *ptr = head;
  int count = 0;

  while(ptr != NULL){
    //keeping going to next node, until the node points to null
    ptr = ptr->next;
    count++;
  }

  return count;
}
//Displays all values in the list in order, starting from the head
template <class T>
void LinkedList<T>::display(){

  Node<T> *ptr = head;

  while(ptr != NULL){
    //similar to size, traversing the list until null is pointed to
    cout << "\nValues: " << ptr->data << endl;
    ptr = ptr->next;
  }

}
//Inserts a node containing the argument into the linked list, fulfilling ascending order
template <class T>
void LinkedList<T>::insertItemSorted(T var){

  Node<T> *prenode = NULL;
  Node<T> *curnode;
  Node<T> *newnode;

  newnode = new Node<T>; //dynamically allocates so it isn't lost when scope ends
  newnode->data = var;


  //check if head is empty
  if(head==NULL){
    head = newnode;
    newnode->next = NULL;
  }
  else{

    curnode = head;
    //keep going until Null is pointed to or data is greater than the input
    while(curnode != NULL && curnode->data<var){
      prenode = curnode;
      curnode = curnode->next;
    }
    //when it is second value but head has a value
    if(prenode==NULL){
      head = newnode;
      newnode->next = curnode;
    }
    else{
      //any other position in list
      prenode->next = newnode;
      newnode-> next = curnode;
    }

  }





}
//Returns whether the linked list contains the provided value or not
template <class T>
bool LinkedList<T>::findValue(T var){
  Node<T> *ptr = head;
  //traverses node looking for var
  while(ptr != NULL){
    if(ptr->data==var){
      return true;
    }

    ptr = ptr->next;
  }
  return false;
}


//If a node is found containing the value passed as an argument, it will be safely removed from the LL
template <class T>
void LinkedList<T>::remove(T var){
  Node<T> *prenode = NULL;
  Node<T> *curnode = head;
//nothing to remove
  if(head==NULL)
    return;

//when the head holds the data
  if(head->data==var){
    curnode = head->next;
    delete head;
    head = curnode;
  }
else{
  //keep going until  var is found and removed (break) or no item is found
  while(curnode != NULL){
    if(curnode->data==var){
      prenode->next =  curnode->next;
      delete curnode;
      break;
    }
    prenode = curnode;
    curnode = curnode->next;
  }


}

}
