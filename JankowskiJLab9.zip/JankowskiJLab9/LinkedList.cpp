
#include "LinkedList.h"

template <class T>
LinkedList<T>::~LinkedList(){
  Node<T> *curnode;
  Node<T> *nextnode;
  curnode = head;

  while(curnode!=NULL){
    nextnode = curnode->next;
     delete curnode;
     curnode = nextnode;
  }



}

template <class T>
int LinkedList<T>::size(){

  Node<T> *ptr = head;
  int count = 0;

  while(ptr != NULL){
    ptr = ptr->next;
    count++;
  }

  return count;
}
//Displays all values in the list in order, starting from the head
template <class T>
void LinkedList<T>::display(){

  Node<T> *ptr = head;

  while(ptr != NULL){
    cout << "\nValues: " << ptr->data << endl;
    ptr = ptr->next;
  }

}
//Inserts a node containing the argument into the linked list, fulfilling ascending order
template <class T>
void LinkedList<T>::insertItemSorted(T var){

  Node<T> *prenode = NULL;
  Node<T> *curnode;
  Node<T> *newnode;

  newnode = new Node<T>;
  newnode->data = var;


  //check if head is empty
  if(head==NULL){
    head = newnode;
    newnode->next = NULL;
  }
  else{

    curnode = head;

    while(curnode != NULL && curnode->data<var){
      prenode = curnode;
      curnode = curnode->next;
    }
    if(prenode==NULL){
      head = newnode;
      newnode->next = curnode;
    }
    else{
      prenode->next = newnode;
      newnode-> next = curnode;
    }

  }





}
//Returns whether the linked list contains the provided value or not
template <class T>
bool LinkedList<T>::findValue(T var){
  Node<T> *ptr = head;
  while(ptr != NULL){
    if(ptr->data==var){
      return true;
    }

    ptr = ptr->next;
  }
  return false;
}


//If a node is found containing the value passed as an argument, it will be safely removed from the LL
template <class T>
void LinkedList<T>::remove(T var){
  Node<T> *prenode = NULL;
  Node<T> *curnode = head;

  if(head==NULL)
    return;

  if(head->data==var){
    curnode = head->next;
    delete head;
    head = curnode;
  }
else{
  while(curnode != NULL){
    if(curnode->data==var){
      prenode->next =  curnode->next;
      delete curnode;
      break;
    }
    prenode = curnode;
    curnode = curnode->next;
  }


}

}
