

/*
Josef Jankowski
CSPC 121 Lab 8
Due: 12/08/18 <-?
*/



#include <iostream>
#include "Gladiator.h"
#include <time.h>
#include <stdlib.h>
#include <vector>

using namespace std;

//main!
int main(){
  //random
srand(time(NULL));

//two vectos
vector<Gladiator> red(5);
bool red_fought = false;
vector<Gladiator> blue(5);
bool blue_fought = false;
//exit condition for do while
bool exit = false;
bool gameover = false;
//ints for later
int option = 0;
int damage = 0;
int index = 0;

//index for each vecctor
unsigned int redindex = 0; unsigned int blueindex = 0;

do{
  //updates team size each loop
  cout<<"\n There are " << red.size() <<" gladiators on the red team and "
  << blue.size() << " gladiators on the blue team\n";

//menu
  cout<< "\nOptions: \n";
  cout<<"1. Fight until each gladiator has fought once\n";
  cout<<"2. Add one gladiator to each side\n";
  cout<<"3. Quit\n";
  cin >> option;

//switch for each option
switch (option) {
  //each gladior fights, at least, once.  do until they all do
  case 1:
    do{
      //all had turns fighting
      if(blue_fought && red_fought){

        break;
      }

      //red attack
      if(rand()%2){

        //iterator goes in order and here it goes back the the begiing
        if(redindex == red.size()){

          red_fought = true;
          redindex = 0;
        }
        //goes through attacking motion
        cout<<"\nRed Team's " <<red[redindex].name <<" attacks!\n";
        damage = red[redindex].rollDamage();

        ++redindex;
        index = rand()%blue.size();

        //checks death
        if(blue[index].takeDamage(damage)){
          cout << "\nBlue Team's " << blue[index].name << " has died\n";
          blue.erase(blue.begin()+index);
          blueindex--;
        }

        //red victoy
        if(blue.size()==0){
          cout<<"\nRed Team is victorious!\n";
          gameover = true;
        }

      }

      //for blue attack
      else{

        //iterator goes in order and here it goes back the the begiing
        if(blueindex == blue.size()){
          blue_fought = true;
          blueindex = 0;
        }

        //attacking
        cout <<"\nBlue team's "<< blue[blueindex].name <<" attacks!\n";
        damage = blue[blueindex].rollDamage();

        ++blueindex;

        index = rand()%red.size();
        //checks death
        if(red[index].takeDamage(damage)){
          cout << "\nRed Team's " << red[index].name << " has died\n";
          red.erase(red.begin()+index);
          redindex--;

        }
        //blue victory
        if(red.size()==0){
          cout<<"\nBlue Team is victorious!\n";
          gameover = true;
        }

    }

//adding default of 5 gladiators if one team won
  if(gameover){

    red.clear();
    blue.clear();
    //adding more gladiators to play
    for(int i = 0; i<5; i++){
      red.push_back(Gladiator());
      blue.push_back(Gladiator());
    }
    blueindex =0; redindex=0;
    break;
  }




  }while(true);
  blue_fought = false; red_fought = false; gameover = false;
  break;

  //adding one gladiator to each team
  case 2:

  red.push_back(Gladiator());
  blue.push_back(Gladiator());



  break;
  //exit
  case 3: exit = true;
  break;
}


}while(!exit);




  return 0;
}
