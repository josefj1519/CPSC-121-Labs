#include "Gladiator.h"

//using namespace std;


Gladiator::Gladiator(){

  static std::string names[10] = { "Alfred", "Bob", "Charles", "David", "Evan", "Fred", "George", "Hector", "Irene", "Jeff" };
  name = names[rand() % 10];
   //cout<<"\nGladiator " << n <<" created.\n";

   //mathed out the values
    dmgMin = (rand()%6)+9;
    dmgRange = (rand()%6) + 17;
    evasion = 5 *  ((rand() % 3)+1);
    critical = 5 *  ((rand() % 3)+1);
    maxHealth = ((rand() % 3)+3) * 50;
    curHealth = maxHealth;

}

int Gladiator::rollDamage(){
  int dmgAmt = dmgMin; //default alue to min

  dmgAmt = dmgMin + (rand()%dmgRange); //random value from range added to min

  //checks for critical
  if((rand() % 100)<= critical){
    dmgAmt *= 2;
    cout << "\n" <<name <<" has a crit!! (double damage)"<<endl;
  }



  return dmgAmt;
}

bool Gladiator::takeDamage(int dmgAmt){
  //checks if evaded
  if((rand() % 100)<= evasion){
    cout<< "\n"<< name<< " evaded!!\n";
    return false;
  }
  cout << "\n" << name << " took " << dmgAmt <<" damage!\n";
  //false if alive, true = dead;
  return (curHealth -= dmgAmt) <= 0;
}

void Gladiator::display(){
  //couts stats at begging
  cout <<"\nName: " << name <<endl;
  cout << "Min Damage: "<<dmgMin<< " Damange Range: " << dmgRange << " Critical: "<<critical <<" Evasion: "<<evasion <<endl;
  cout<< "Max Health: "<<maxHealth<< " Current Health: "<<curHealth<< endl;
}

int Gladiator::getCurHealth()
{
	return curHealth;
}
