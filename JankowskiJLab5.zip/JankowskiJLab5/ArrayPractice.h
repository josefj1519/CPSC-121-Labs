

#ifndef _ARRAYPRACTICE_H //checks if its define

#define _ARRAYPRACTICE_H //defines it


#include <iostream>
#include <stdlib.h> //random
//#include <algorithm> /swap, however swap ened up breaking it.  leaving it here for refrence

using namespace std;

//SIZE OF ARRAY
const int SIZE = 5;

class ArrayPractice{

public:

  int doot[SIZE]; //array creation

  int result = 0;  //to satisfy conditions

//inline constructor
  ArrayPractice(){
    editArray();
  }

  void displayArray();

  void editArray();

  void getSum(int arr[], int &result); //to satisfy conditions

  double getMean();

  void getSequence();

  bool getSearch(int num);

  void selectionSort();

  bool isSorted();

  void bogoSort();

};

#endif
