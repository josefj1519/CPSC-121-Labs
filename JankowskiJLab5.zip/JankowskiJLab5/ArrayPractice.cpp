
#include "ArrayPractice.h"

//made it inline
/*
ArrayPractice::ArrayPractice(){

}
*/

//displays array
void  ArrayPractice::displayArray(){
  cout<<"----------------------\n";
  for(int i=0;i<SIZE;i++){
    cout<< doot[i];
    cout<<"\n";
  }
  cout<<"----------------------\n";
}

//edits the array
void ArrayPractice::editArray(){
  cout<< "Enter a new array of size 5:\n\n";
  for(int i=0; i<SIZE;i++){
    cin >> doot[i];
    cout<< "\n";
  }
  cout<< "Array Edited\n";

}

void ArrayPractice::getSum(int arr[], int &result){ //to satisfy refrence variable
  for(int i = 0;i<SIZE; i++){
    result += arr[i]; //simply goes through the array and adds up the values
  }
}

double ArrayPractice::getMean(){
  int result = 0;
  getSum(doot, result);
  return (double)(result)/2; //returns the result of getSum which uses refrence variables
}

void ArrayPractice::getSequence(){
  cout<< "Sequence:\n";
  for(int i = 0; i<SIZE-1;i++){
    cout << doot[i+1] - doot[i] << endl << endl; //difference of the array values
  }
}

bool ArrayPractice::getSearch(int num){
  //searchs for num which the user inputed
  for(int i =0;i<SIZE; i++){
    if(doot[i] == num){
      return true;
    }
  }
  return false;

}

void ArrayPractice::selectionSort(){
  int min = 0;
  int count = 0;
  int fun_counter = 0; //swap counter
  int temp = -1;

  do{

    //set min to first value of array
    min = doot[count];
    //shorten search array each time because values before count are already sorted
    for(int i = count+1;i<SIZE;i++){
      if(doot[i]<min){
        //remeber the min value
        min = doot[i];
        temp = i;

      }
    }
    //dont want to swap the same values
    if(min != doot[count]){
      //swap different values
      doot[temp] = doot[count];
      doot[count] = min;
      fun_counter++;
    }
    //swap(doot[temp],doot[count]);


    count++;

  }while(count<SIZE-1);

  cout<<"Swapped " << fun_counter << " times.\n\n";

  displayArray();
}

bool ArrayPractice::isSorted(){
  //for bogo sort to check if in order
  for(int i = 0;i<SIZE-1;i++){
    if(doot[i]>doot[i+1]){

      return false;
    }
  }
  return true;
}




void ArrayPractice::bogoSort(){
  int counter = 0; // counter for shuffles
  int temp = 0;
  while(!isSorted()){
    for(int i =0;i<SIZE;i++){
      //random swap. need to remeber which random num it is
      int num = rand()%SIZE;
      temp = doot[i];
      doot[i] = doot[num];
      doot[num] = temp;

    //  swap(doot[i], doot[rand()%SIZE]);
    }
    counter++;
  }
  cout <<"Shuffled "<< counter << " times.\n\n";
  displayArray();

}
