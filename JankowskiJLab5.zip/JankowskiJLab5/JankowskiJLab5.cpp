
/*
Josef Jankowski
CSPC 121 Lab 5
Due: 011/02/18
*/


#include <iostream>
#include <unistd.h> //sleep
#include "ArrayPractice.h"
using namespace std;

int main(){

  bool GO = true;
  //class that contains the array and methods
  ArrayPractice r1;

  do {
    //sleept so the response wouldnt get pushed by menu immediatley
    sleep(1);
    //menu
    cout << endl;
    cout<<"Menu of Arrays!\n";
    cout<<"*****************************\n";
    cout<<"1.     Edit Array\n";
    cout<<"2.     Get Sum\n";
    cout<<"3.     Get Mean\n";
    cout<<"4.     Get Sequence\n";
    cout<<"5.     Search\n";
    cout<<"6.     Selection Sort\n";
    cout<<"7.     B0G0\n";
    cout<<"8.     Display Array\n";
    cout<<"9.     Exit\n";
    cout<<"*****************************\n\n";


    int choice;

    cin >> choice;

    //cases
    switch (choice) {
      case 1: r1.editArray(); break;

      case 2: r1.getSum(r1.doot, r1.result);
              cout<< r1.result<< endl;
              break;
      case 3: cout<<"Mean: " << r1.getMean() << endl;
              break;
      case 4: r1.getSequence(); break;
      //requires input from the user
      case 5: cout << "What number you like to search for?\n";
              int num;
              cin >> num;
              if(r1.getSearch(num))
                cout<< num << " was found\n";
              else
                cout<<num<<" was not found\n";
              break;
      case 6: r1.selectionSort(); break;
      case 7: r1.bogoSort(); break;
      case 8: r1.displayArray();break;
      case 9: GO = false; break;
    }
  } while(GO);


  return 0;
}
