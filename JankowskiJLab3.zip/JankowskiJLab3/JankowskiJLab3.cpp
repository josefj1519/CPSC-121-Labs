/*
Josef Jankowski
CSPC 121 Lab 3
Due: 09/30/18
*/

#include <iostream>
#include <fstream>
#include <string>
#include "Shape.h"
#include "Rectangle.h"
#include "Triangle.h"
using namespace std;

int main(){

  //exit bool for exiting dool while loop
  bool go = true;

  //do because it is going to start in the begining any way
  do{

    //ask the user for a char input do to decide which object im going to use
    char ch = ' ';
    cout << "Chose rectangle or triangle (r/t)\n";
    cin >> ch;

    //Parent class shape and using it as a pointer to either be able to point to either of its dervied classes
    Shape* s1;

    //parent -> child class polymorphism
    if(ch == 'r'){
      s1 = new Rectangle();
    }
    else{
      s1 = new Triangle();
    }

    //calling methods used by both child classes to draw the shape
    (*s1).getInput();
    (*s1).drawNum();


    //ask the user if he wants to play again and if not exit the program
    char c;
    cout << "Do you want to play again? (y/n)";
    cin >> c;
    if(c != 'y')
      go = false;

    delete s1;

  }while(go);



  return 0;

}
