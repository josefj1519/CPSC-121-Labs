
//from my understanding ifndef checks if shape has been previously defined and if not it runs
//this is so the preprocessor doesn't define the class again
#ifndef _SHAPE_H
//defines shape here
#define _SHAPE_H
#include <string>
#include <fstream>
#include <iostream>
using namespace std;


class Shape{

protected:
  ofstream output;
  char print;
  string word = "*"; //default is star changes to word if user wants
  int width = 1; // 1 is the default width to draw something (need something to draw)


//public since some of these methods will be called in main
public:
//some of these methods have the virtual type becuase some of them will be used in the derived classes
  virtual ~Shape();
//shared method to get word or the width and wether to print in console or file
  void getInput();

  void virtual drawNum();

  void virtual getWordWidth();

};

//ends the preprocessor
#endif
