
//include header
#include "Triangle.h"


//getting direction from user wether to print up or down
bool Triangle::isUp(){
    char dir;
    cout << "Is the triangle pointing up or down (u/d)\n";
    cin >> dir;
    if(dir=='u'){
      return true;
    }
    else{
      return false;
    }
  }

//getting the width
  void Triangle::getWordWidth(){

    cout << "What will be your word?\n";
    cin.ignore(); //since i previously asked for input i need to clear the line or ignore
    getline (cin, word);
    width = word.length(); //setting width equal to word length
  }

  bool Triangle::printTriangle(int a, int b){
    if(word == "*"){
      if(print=='c')
        cout << word;
        else
        output << word;
      }
      else{
        if(print == 'c')
          cout << word.substr(a, b);
        else
          output << word.substr(a, b);
        return true;
      }
      return false;
  }

  //draw num method
  void Triangle::drawNum(){

    //cout<<"\n";

    if(print == 'f'){
      output.open("myshape.txt");
    }
      //this is for triangle facing  up
    bool up = isUp();
    
    if((up && word != "*") ||( !up && word =="*")){
      int  count = width;
      while(count>=0){
        for(int i=0;i<count;i++){
        //if not using word go here
          if(printTriangle(count-1, width))
            break;
          //using word

        }
        if(print == 'c')
          cout << "\n";
        else
          output << "\n";
        count--;
      }
  }

//triangle facing down
  else{
    int count = 0;
    while(count<width){
      for(int i=count;i>=0;i--){
        if(printTriangle(count, width))
          break;
      }
      if(print == 'c')
        cout << "\n";
      else
        output << "\n";
      count++;
    }
  }
  output.close();
  }
