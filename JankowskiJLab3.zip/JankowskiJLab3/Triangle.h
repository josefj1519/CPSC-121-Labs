//from my understanding ifndef checks if shape has been previously defined and if not it runs
//this is so the preprocessor doesn't define the class again
#ifndef _TRIANGLE_H
//defines shape here
#define _TRIANGLE_H

#include "Shape.h"
#include <string>
using namespace std;

class Triangle: public Shape{

protected:

  //methods to be use in the class
  bool isUp();

  void checkWidth();

  void getWordWidth();

  //draw num method
  void drawNum();

private:

  bool printTriangle(int a, int b);

};


//end here
#endif
