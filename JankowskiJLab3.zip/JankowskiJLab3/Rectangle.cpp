
#include "Rectangle.h"


//RECTANGLE CLASS

  Rectangle::Rectangle(){
  //in the constructor need to get the height of the rectangle
    getHeight();
  }

  void Rectangle::getHeight(){
    //saving a FULL two lines of code /s
    cout<<"Height of your rectangle?\n";
    cin >> height;
  }

  //drawing rectangle when not getting a word
  void Rectangle::drawNum(){
    //open file
    output.open("myshape.txt");
    //double for loop to draw the rectangle.  one loop for repeating height and the second for width
    for(int i = 0; i<height; i++){
      for(int j = 0; j<width; j++){
        if(print == 'c')
          cout << word;
        else
          output << word;
      }
      if(print == 'c')
        cout << "\n";
      else
        output << "\n";
    }
    //  close file
    output.close();
  }
