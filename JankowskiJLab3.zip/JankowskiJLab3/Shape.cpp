
// need to inclue the header file of shape
#include "Shape.h"

//yelled at me to put a destructor
  Shape::~Shape(){}


  //shared method to get word or the width and wether to print in console or file
  void Shape::getInput(){
    char w;
    cout << "Will you supply us with the width or a word (e/p)?\n";
    cin >> w;
    if(w == 'e'){
      cout << "What will be your width?\n ";
      //changing width to what user inputed
      cin >> width;
    }
    else{
      //if the user entered a word we now need to set the width = to word width
      getWordWidth();
    }

    cout << "Do you want to print your shape to a file or to the console (f/c)?\n";
    cin >> print;
  }
  //dont need to state its virtual twice
  //drawnum is only used in child
  void Shape::drawNum(){}

  void Shape::getWordWidth(){
    cout << "What will be your word?\n";
    cin.ignore(); //since i previously asked for input i need to clear the line
    getline (cin, word); //getting word here for rectangle.  triangle will overide this
  }
