//from my understanding ifndef checks if shape has been previously defined and if not it runs
//this is so the preprocessor doesn't define the class again
#ifndef _RECTANGLE_H
//definees rectangle now
#define _RECTANGLE_H

//parent class
#include "Shape.h"
using namespace std;


//RECTANGLE CLASS
class Rectangle: public Shape{
public:
  //constructor
  Rectangle();


protected:
  //only used by rect
  int height;
  void getHeight();

  //drawing rectangle when not getting a word
  void drawNum();

};
#endif
